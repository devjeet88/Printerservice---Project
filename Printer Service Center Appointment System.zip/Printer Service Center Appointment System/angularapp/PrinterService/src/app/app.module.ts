import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule, Route, Routes } from '@angular/router';
import { RouterOutlet} from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AddcenterComponent } from './addcenter/addcenter.component';
import { AppComponent } from './app.component';
import { ToastrModule } from 'ngx-toastr';
import { RegisterModel, SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { HomepageComponent } from './homepage/homepage.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { NgbModule, NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { CenterProfileComponent } from './center-profile/center-profile.component'; 
import { LoginService } from 'src/service/login.service';
import { RegisterService } from 'src/service/register.service';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { EditcenterComponent } from './editcenter/editcenter.component';
import { EditappointmentComponent } from './editappointment/editappointment.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

const routes: Routes = [
  {path:'',redirectTo:'user/login',pathMatch:'full'},
  { path: 'user/login', component:LoginComponent},
  { path: 'user/homepage', component: HomepageComponent },
  { path: 'logout', component: LoginComponent },
  { path: 'user/dashboard', component: DashboardComponent },
  { path: 'user/mybookings', component: AppointmentComponent } ,
  { path: 'user/signup', component:SignupComponent},
  {path:'admin/homepage', component:AdminhomeComponent},
  {path:'admin/addcenter',component:AddcenterComponent},
  {path:'admin/centerprofile', component:CenterProfileComponent},
  {path:'admin/editcenter', component:EditcenterComponent},
  {path:'user/appointment',component:AppointmentComponent},
  {path:'user/editappointment',component:EditappointmentComponent}
  
  ];
@NgModule({
  declarations: [
    AppComponent,
    
    SignupComponent,
    LoginComponent,
    HomepageComponent,
    DashboardComponent,
    AppointmentComponent,
    AddcenterComponent,
    CenterProfileComponent,
    AdminhomeComponent,
    EditcenterComponent,
    EditappointmentComponent,
    
    
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    NgbModule
  
    

  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
}
