import { Component,EventEmitter, OnInit, Output  } from '@angular/core';

@Component({
  selector: 'app-editcenter',
  templateUrl: './editcenter.component.html',
  styleUrls: ['./editcenter.component.css']
})
export class EditcenterComponent {

}
